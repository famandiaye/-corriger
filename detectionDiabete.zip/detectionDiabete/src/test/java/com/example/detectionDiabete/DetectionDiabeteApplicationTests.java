package com.example.detectionDiabete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetectionDiabeteApplicationTests {

	@Test
	void contextLoads() {
	}

}
