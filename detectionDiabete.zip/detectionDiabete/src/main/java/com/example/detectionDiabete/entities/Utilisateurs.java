package com.example.detectionDiabete.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@NoArgsConstructor // Constructeur sans paramètres
@AllArgsConstructor
@Entity
@Data
@Inheritance(strategy = InheritanceType.JOINED)
public class Utilisateurs implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;
    private String prenom;
    private String email;
    private String motDePasse;
    private String telephone;
    private Date dateDeNaissance;

    @Enumerated(EnumType.STRING) // Pour stocker le rôle sous forme de chaîne
    private Role role; // Rôle de l'utilisateur (ex : MÉDECIN, PATIENT, ADMIN)

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(() -> role.name()); // Retourner le rôle comme une autorité
    }

    @Override
    public String getPassword() {
        return motDePasse;
    }

    @Override
    public String getUsername() {
        return email; // Utilisez l'email comme nom d'utilisateur
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Vous pouvez ajouter une logique si nécessaire
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Vous pouvez ajouter une logique si nécessaire
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Vous pouvez ajouter une logique si nécessaire
    }

    @Override
    public boolean isEnabled() {
        return true; // Vous pouvez ajouter une logique si nécessaire
    }

    public void setDateDeNaissance(String dateDeNaissance) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        this.dateDeNaissance = dateFormat.parse(dateDeNaissance);
    }
}
