package com.example.detectionDiabete.Controller;

public class ResultatPatientController {
}
