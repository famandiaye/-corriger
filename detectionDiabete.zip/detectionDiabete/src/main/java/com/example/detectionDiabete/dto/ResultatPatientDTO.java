package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data

public class ResultatPatientDTO {
    private Long id;
    private Long idPatient;
    private Long idMedecin;
    private String resultat; // Résultat du test
    private LocalDateTime dateReception; // Date de réception du résultat
}
