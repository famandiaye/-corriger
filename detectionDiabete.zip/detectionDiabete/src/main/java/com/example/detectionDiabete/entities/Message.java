package com.example.detectionDiabete.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long idMedecin; // ID du médecin
    private Long idPatient; // ID du patient
    private String contenu; // Contenu du message
    private LocalDateTime dateEnvoi; // Date d'envoi du message
}
