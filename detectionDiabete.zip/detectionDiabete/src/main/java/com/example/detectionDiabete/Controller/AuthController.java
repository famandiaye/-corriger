package com.example.detectionDiabete.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.detectionDiabete.dto.UtilisateursDTO;
import com.example.detectionDiabete.dto.LoginRequest;
import com.example.detectionDiabete.services.UtilisateurService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UtilisateurService utilisateurService;

    // Inscription d'un nouvel utilisateur
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UtilisateursDTO userDto) {
        try {
            utilisateurService.register(userDto);
            return ResponseEntity.ok("Utilisateur créé avec succès.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur : " + e.getMessage());
        }
    }

    // Connexion d'un utilisateur
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        try {
            String token = utilisateurService.login(loginRequest);
            return ResponseEntity.ok(token);
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body("Erreur d'authentification : " + e.getMessage());
        }
    }
}
