package com.example.detectionDiabete.dto;

import lombok.Data;

@Data
public class DossierMedicalDTO {
    private Long id;
    private Long patientId; // ID du patient associé au dossier médical
    private String historiqueMaladies;
    private String notesMedecin;

}
