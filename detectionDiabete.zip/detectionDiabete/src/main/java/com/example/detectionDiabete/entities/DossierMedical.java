package com.example.detectionDiabete.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
public class DossierMedical {

    @Id // Utilisation de l'annotation correcte pour les entités JPA
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    private Patient patient; // Un dossier médical appartient à un seul patient

    @OneToMany(cascade = CascadeType.ALL)
    private List<Ordonnance> ordonnances; // Les ordonnances associées au patient

    private String historiqueMaladies; // Historique des maladies du patient
    private String notesMedecin; // Notes ajoutées par le médecin
}
