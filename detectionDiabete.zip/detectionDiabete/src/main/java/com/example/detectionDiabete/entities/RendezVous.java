package com.example.detectionDiabete.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "rendezvous")
public class RendezVous {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_medecin", nullable = false)
    private Long idMedecin;

    @Column(name = "id_patient", nullable = false)
    private Long idPatient;

    @Column(nullable = false)
    private LocalDateTime dateRendezVous;

    @Column(nullable = false)
    private String statut = "Proposé"; // Statut par défaut : "Proposé"
}
