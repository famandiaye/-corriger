package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.Utilisateurs;
import com.example.detectionDiabete.Repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    // Créer un nouvel utilisateur
    public Utilisateurs creerUtilisateur(Utilisateurs utilisateur) {
        return utilisateurRepository.save(utilisateur);
    }

    // Mettre à jour un utilisateur existant
    public Utilisateurs mettreAJourUtilisateur(Long id, Utilisateurs utilisateurDetails) {
        Utilisateurs utilisateur = utilisateurRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé avec ID: " + id));

        utilisateur.setNom(utilisateurDetails.getNom());
        utilisateur.setEmail(utilisateurDetails.getEmail());
        // Ne pas mettre à jour le mot de passe directement; il doit être géré de manière sécurisée
        utilisateurRepository.save(utilisateur);
        return utilisateur;
    }

    // Supprimer un utilisateur
    public void supprimerUtilisateur(Long id) {
        Utilisateurs utilisateur = utilisateurRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé avec ID: " + id));
        utilisateurRepository.delete(utilisateur);
    }

    // Récupérer tous les utilisateurs
    public List<Utilisateurs> recupererTousLesUtilisateurs() {
        return utilisateurRepository.findAll();
    }

    // Récupérer un utilisateur par ID
    public Utilisateurs recupererUtilisateurParId(Long id) {
        return utilisateurRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé avec ID: " + id));
    }
}
