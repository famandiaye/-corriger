package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.dto.OrdonnanceDTO;
import com.example.detectionDiabete.entities.Ordonnance;
import com.example.detectionDiabete.services.OrdonnanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ordonnances")
public class OrdonnanceController {

    @Autowired
    private OrdonnanceService ordonnanceService;

    // Prescrire un médicament
    @PostMapping("/prescrire")
    public ResponseEntity<OrdonnanceDTO> prescrireMedicament(@RequestBody OrdonnanceDTO ordonnanceDTO) {
        OrdonnanceDTO ordonnance = ordonnanceService.prescrireMedicament(ordonnanceDTO);
        return ResponseEntity.ok(ordonnance);
    }

    // Récupérer les ordonnances par patient
    @GetMapping("/patient/{idPatient}")
    public ResponseEntity<List<OrdonnanceDTO>> recupererOrdonnances(@PathVariable Long idPatient) {
        List<OrdonnanceDTO> ordonnances = ordonnanceService.recupererOrdonnances(idPatient);
        return ResponseEntity.ok(ordonnances);
    }

    // Récupérer une ordonnance par son ID
    @GetMapping("/{idOrdonnance}")
    public ResponseEntity<Ordonnance> recupererOrdonnance(@PathVariable Long idOrdonnance) {
        Ordonnance ordonnance = ordonnanceService.recupererOrdonnance(idOrdonnance);
        return ResponseEntity.ok(ordonnance);
    }

    // Mettre à jour une ordonnance
    @PutMapping("/{idOrdonnance}")
    public ResponseEntity<Ordonnance> mettreAJourOrdonnance(@PathVariable Long idOrdonnance,
                                                            @RequestBody OrdonnanceDTO ordonnanceDTO) {
        Ordonnance updatedOrdonnance = ordonnanceService.mettreAJourOrdonnance(idOrdonnance, ordonnanceDTO);
        return ResponseEntity.ok(updatedOrdonnance);
    }

    // Supprimer une ordonnance
    @DeleteMapping("/{idOrdonnance}")
    public ResponseEntity<Void> supprimerOrdonnance(@PathVariable Long idOrdonnance) {
        ordonnanceService.supprimerOrdonnance(idOrdonnance);
        return ResponseEntity.noContent().build();
    }
}
