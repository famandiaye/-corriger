package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.dto.RendezVousDTO;
import com.example.detectionDiabete.entities.RendezVous;
import com.example.detectionDiabete.services.RendezVousService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rendezvous")
public class RendezVousController {

    @Autowired
    private RendezVousService rendezVousService;

    // Proposer un rendez-vous
    @PostMapping("/proposer")
    public ResponseEntity<RendezVous> proposerRendezVous(@RequestBody RendezVousDTO rendezVousDTO) {
        RendezVous rendezVous = rendezVousService.proposerRendezVous(
                rendezVousDTO.getIdMedecin(),
                 rendezVousDTO.getIdPatient(),
                rendezVousDTO.getDateRendezVous()
        );
        return ResponseEntity.ok(rendezVous);
    }

    // Confirmer un rendez-vous
    @PostMapping("/confirmer/{id}")
    public ResponseEntity<Void> confirmerRendezVous(@PathVariable Long id) {
        rendezVousService.confirmerRendezVous(id);
        return ResponseEntity.noContent().build();
    }

    // Annuler un rendez-vous
    @PostMapping("/annuler/{id}")
    public ResponseEntity<Void> annulerRendezVous(@PathVariable Long id) {
        rendezVousService.annulerRendezVous(id);
        return ResponseEntity.noContent().build();
    }

    // Récupérer les rendez-vous d'un patient
    @GetMapping("/patient/{idPatient}")
    public ResponseEntity<List<RendezVous>> recupererRendezVousParPatient(@PathVariable Long idPatient) {
        List<RendezVous> rendezVous = rendezVousService.recupererRendezVousParPatient(idPatient);
        return ResponseEntity.ok(rendezVous);
    }

    // Récupérer les rendez-vous d'un médecin
    @GetMapping("/medecin/{idMedecin}")
    public ResponseEntity<List<RendezVous>> recupererRendezVousParMedecin(@PathVariable Long idMedecin) {
        List<RendezVous> rendezVous = rendezVousService.recupererRendezVousParMedecin(idMedecin);
        return ResponseEntity.ok(rendezVous);
    }
}
