package com.example.detectionDiabete.Repository;

import com.example.detectionDiabete.entities.Ordonnance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrdonnanceRepository extends JpaRepository<Ordonnance, Long> {

    // Méthode pour trouver les ordonnances par l'ID du patient
    List<Ordonnance> findByPatient_Id(Long patientId);
}
