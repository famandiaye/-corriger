package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.Ordonnance;
import com.example.detectionDiabete.entities.Patient;
import com.example.detectionDiabete.entities.Medecin;
import com.example.detectionDiabete.Repository.OrdonnanceRepository;
import com.example.detectionDiabete.dto.OrdonnanceDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrdonnanceService {

    @Autowired
    private OrdonnanceRepository ordonnanceRepository;

    @Autowired
    private PatientService patientService;

    @Autowired
    private MedecinService medecinService;

    // Prescrire un médicament
    public OrdonnanceDTO prescrireMedicament(OrdonnanceDTO ordonnanceDTO) {
        Patient patient = patientService.findPatientById(ordonnanceDTO.getIdPatient());
        Medecin medecin = medecinService.getMedecinById(ordonnanceDTO.getIdMedecin());

        Ordonnance ordonnance = new Ordonnance();
        ordonnance.setNom(ordonnanceDTO.getNom());
        ordonnance.setDescription(ordonnanceDTO.getDescription());
        ordonnance.setDosage(ordonnanceDTO.getDosage());
        ordonnance.setPatient(patient);
        ordonnance.setMedecin(medecin);

        Ordonnance savedOrdonnance = ordonnanceRepository.save(ordonnance);

        return new OrdonnanceDTO(
                savedOrdonnance.getId(),
                savedOrdonnance.getNom(),
                savedOrdonnance.getDescription(),
                savedOrdonnance.getDosage(),
                savedOrdonnance.getPatient().getId(),
                savedOrdonnance.getMedecin().getId()
        );
    }

    // Récupérer les ordonnances d'un patient
    public List<OrdonnanceDTO> recupererOrdonnances(Long idPatient) {
        List<Ordonnance> ordonnances = ordonnanceRepository.findByPatient_Id(idPatient);
        return ordonnances.stream()
                .map(ordonnance -> new OrdonnanceDTO(
                        ordonnance.getId(),
                        ordonnance.getNom(),
                        ordonnance.getDescription(),
                        ordonnance.getDosage(),
                        ordonnance.getPatient().getId(),
                        ordonnance.getMedecin().getId()
                ))
                .collect(Collectors.toList());
    }

    // Récupérer une ordonnance par son ID
    public Ordonnance recupererOrdonnance(Long idOrdonnance) {
        return ordonnanceRepository.findById(idOrdonnance)
                .orElseThrow(() -> new RuntimeException("Ordonnance non trouvée"));
    }

    // Mettre à jour une ordonnance
    public Ordonnance mettreAJourOrdonnance(Long idOrdonnance, OrdonnanceDTO ordonnanceDTO) {
        Ordonnance ordonnance = recupererOrdonnance(idOrdonnance);
        ordonnance.setNom(ordonnanceDTO.getNom());
        ordonnance.setDescription(ordonnanceDTO.getDescription());
        ordonnance.setDosage(ordonnanceDTO.getDosage());

        if (ordonnanceDTO.getIdPatient() != null) {
            Patient patient = patientService.findPatientById(ordonnanceDTO.getIdPatient());
            ordonnance.setPatient(patient);
        }
        if (ordonnanceDTO.getIdMedecin() != null) {
            Medecin medecin = medecinService.getMedecinById(ordonnanceDTO.getIdMedecin());
            ordonnance.setMedecin(medecin);
        }
        return ordonnanceRepository.save(ordonnance);
    }

    // Supprimer une ordonnance
    public void supprimerOrdonnance(Long idOrdonnance) {
        Ordonnance ordonnance = recupererOrdonnance(idOrdonnance);
        ordonnanceRepository.delete(ordonnance);
    }
}
