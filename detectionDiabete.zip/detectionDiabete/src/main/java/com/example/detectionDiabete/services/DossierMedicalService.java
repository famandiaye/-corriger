package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.DossierMedical;
import com.example.detectionDiabete.entities.Patient;
import com.example.detectionDiabete.Repository.DossierMedicalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class DossierMedicalService {

    @Autowired
    private DossierMedicalRepository dossierMedicalRepository;

    @Autowired
    private PatientService patientService;

    // Créer un dossier médical pour un patient
    public DossierMedical creerDossierMedical(Long patientId) {
        // Vérifier si le patient existe
        Patient patient = patientService.findPatientById(patientId);
        if (patient == null) {
            throw new RuntimeException("Patient non trouvé avec ID: " + patientId);
        }

        // Vérifier si un dossier médical existe déjà pour ce patient
        Optional<DossierMedical> existingDossier = dossierMedicalRepository.findByPatient_Id(patientId);
        if (existingDossier.isPresent()) {
            throw new RuntimeException("Un dossier médical existe déjà pour ce patient.");
        }

        // Créer un nouveau dossier médical et l'associer au patient
        DossierMedical dossierMedical = new DossierMedical();
        dossierMedical.setPatient(patient);

        // Sauvegarder le dossier médical dans la base de données
        return dossierMedicalRepository.save(dossierMedical);
    }

    // Consulter un dossier médical par l'ID du patient
    public Optional<DossierMedical> obtenirDossierMedicalParPatientId(Long patientId) {
        // Récupérer le dossier médical pour le patient
        return dossierMedicalRepository.findByPatient_Id(patientId);
    }

    // Mettre à jour un dossier médical existant
    public DossierMedical mettreAJourDossierMedical(Long dossierId, String historiqueMaladies, String notesMedecin) {
        // Récupérer le dossier médical par son ID
        DossierMedical dossierMedical = dossierMedicalRepository.findById(dossierId)
                .orElseThrow(() -> new RuntimeException("Dossier médical non trouvé avec ID: " + dossierId));

        // Mettre à jour les informations du dossier médical
        dossierMedical.setHistoriqueMaladies(historiqueMaladies);
        dossierMedical.setNotesMedecin(notesMedecin);

        // Sauvegarder les modifications
        return dossierMedicalRepository.save(dossierMedical);
    }

    // Supprimer un dossier médical par son ID
    public void supprimerDossierMedical(Long dossierId) {
        // Vérifier si le dossier médical existe
        DossierMedical dossierMedical = dossierMedicalRepository.findById(dossierId)
                .orElseThrow(() -> new RuntimeException("Dossier médical non trouvé avec ID: " + dossierId));

        // Supprimer le dossier médical
        dossierMedicalRepository.delete(dossierMedical);
    }

    // Récupérer tous les dossiers médicaux (si besoin)
    public Iterable<DossierMedical> obtenirTousLesDossiers() {
        return dossierMedicalRepository.findAll();
    }

    // Vérifier si un dossier médical existe pour un patient
    public boolean existeDossierPourPatient(Long patientId) {
        return dossierMedicalRepository.findByPatient_Id(patientId).isPresent();
    }
}
