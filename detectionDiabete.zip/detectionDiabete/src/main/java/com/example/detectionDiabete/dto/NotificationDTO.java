package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data

public class NotificationDTO {
    private Long id;
    private Long idMedecin;
    private Long idPatient;
    private String message;
    private LocalDateTime date; // Date de la notification
}
