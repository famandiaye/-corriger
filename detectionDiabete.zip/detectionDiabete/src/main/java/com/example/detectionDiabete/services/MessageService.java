package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.Message;
import com.example.detectionDiabete.Repository.MessageRepository; // Assurez-vous d'importer MessageRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MessageService {

    @Autowired
    private MessageRepository messageRepository; // Changez ceci pour utiliser le bon repository

    // Logique pour envoyer un message
    public Message envoyerMessage(Long idMedecin, Long idPatient, String contenu) {
        Message message = new Message(); // Assurez-vous que l'entité Message existe
        message.setIdMedecin(idMedecin);
        message.setIdPatient(idPatient);
        message.setContenu(contenu);
        message.setDateEnvoi(LocalDateTime.now()); // Utilisation de LocalDateTime

        return messageRepository.save(message); // Sauvegarde du message dans la base de données
    }

    // Récupérer tous les messages échangés entre un médecin et un patient
    public List<Message> recupererMessages(Long idMedecin, Long idPatient) {
        return messageRepository.findAll() // Récupérer tous les messages de la base de données
                .stream()
                .filter(msg -> msg.getIdMedecin().equals(idMedecin) && msg.getIdPatient().equals(idPatient))
                .collect(Collectors.toList());
    }

    // Récupérer tous les messages pour un médecin spécifique
    public List<Message> recupererMessagesPourMedecin(Long idMedecin) {
        return messageRepository.findAll()
                .stream()
                .filter(msg -> msg.getIdMedecin().equals(idMedecin))
                .collect(Collectors.toList());
    }

    // Récupérer tous les messages pour un patient spécifique
    public List<Message> recupererMessagesPourPatient(Long idPatient) {
        return messageRepository.findAll()
                .stream()
                .filter(msg -> msg.getIdPatient().equals(idPatient))
                .collect(Collectors.toList());
    }
}
