package com.example.detectionDiabete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetectionDiabeteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetectionDiabeteApplication.class, args);
	}

}
