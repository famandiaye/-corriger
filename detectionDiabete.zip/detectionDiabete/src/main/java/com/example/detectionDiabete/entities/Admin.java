package com.example.detectionDiabete.entities;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("ADMIN") // Valeur qui sera stockée dans la colonne de discrimination
public class Admin extends Utilisateurs {


}
