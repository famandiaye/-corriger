package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.RendezVous;
import com.example.detectionDiabete.entities.Notification;
import com.example.detectionDiabete.Repository.RendezVousRepository;
import com.example.detectionDiabete.Repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RendezVousService {

    @Autowired
    private RendezVousRepository rendezVousRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    // Proposer un rendez-vous
    public RendezVous proposerRendezVous(Long idMedecin, Long idPatient, LocalDateTime date) {
        if (date.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("La date du rendez-vous doit être dans le futur.");
        }

        RendezVous rendezVous = new RendezVous();
        rendezVous.setIdMedecin(idMedecin);
        rendezVous.setIdPatient(idPatient);
        rendezVous.setDateRendezVous(date);
        rendezVous.setStatut("Proposé");
        rendezVousRepository.save(rendezVous);

        creerNotification(idMedecin, idPatient, "Nouveau rendez-vous proposé à la date : " + date);
        return rendezVous;
    }

    // Confirmer un rendez-vous
    public void confirmerRendezVous(Long rendezVousId) {
        RendezVous rendezVous = rendezVousRepository.findById(rendezVousId)
                .orElseThrow(() -> new RuntimeException("Rendez-vous non trouvé"));

        rendezVous.setStatut("Confirmé");
        rendezVousRepository.save(rendezVous);

        creerNotification(rendezVous.getIdMedecin(), rendezVous.getIdPatient(),
                "Rendez-vous confirmé à la date : " + rendezVous.getDateRendezVous());
    }

    // Annuler un rendez-vous
    public void annulerRendezVous(Long rendezVousId) {
        RendezVous rendezVous = rendezVousRepository.findById(rendezVousId)
                .orElseThrow(() -> new RuntimeException("Rendez-vous non trouvé"));

        rendezVous.setStatut("Annulé");
        rendezVousRepository.save(rendezVous);

        creerNotification(rendezVous.getIdMedecin(), rendezVous.getIdPatient(),
                "Rendez-vous annulé à la date : " + rendezVous.getDateRendezVous());
    }

    // Récupérer les rendez-vous par patient
    public List<RendezVous> recupererRendezVousParPatient(Long idPatient) {
        return rendezVousRepository.findByIdPatient(idPatient);
    }

    // Récupérer les rendez-vous par médecin
    public List<RendezVous> recupererRendezVousParMedecin(Long idMedecin) {
        return rendezVousRepository.findByIdMedecin(idMedecin);
    }

    // Méthode privée pour créer une notification
    private void creerNotification(Long idMedecin, Long idPatient, String message) {
        Notification notification = new Notification();
        notification.setIdMedecin(idMedecin);
        notification.setIdPatient(idPatient);
        notification.setMessage(message);
        notificationRepository.save(notification);
    }
}
