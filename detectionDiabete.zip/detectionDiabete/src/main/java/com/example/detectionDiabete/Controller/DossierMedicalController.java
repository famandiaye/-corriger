package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.dto.DossierMedicalDTO;
import com.example.detectionDiabete.entities.DossierMedical;
import com.example.detectionDiabete.services.DossierMedicalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dossiers-medicaux")
public class DossierMedicalController {

    @Autowired
    private DossierMedicalService dossierMedicalService;

    // Créer un nouveau dossier médical pour un patient
    @PostMapping("/creer")
    public ResponseEntity<DossierMedicalDTO> creerDossierMedical(@RequestBody DossierMedicalDTO dossierMedicalDTO) {
        try {
            DossierMedical dossierMedical = dossierMedicalService.creerDossierMedical(dossierMedicalDTO.getPatientId());
            return ResponseEntity.ok(convertirEnDTO(dossierMedical));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null); // Vous pouvez personnaliser la réponse d'erreur
        }
    }

    // Obtenir un dossier médical par l'ID du patient
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<DossierMedicalDTO> obtenirDossierMedicalParPatientId(@PathVariable Long patientId) {
        return dossierMedicalService.obtenirDossierMedicalParPatientId(patientId)
                .map(dossierMedical -> ResponseEntity.ok(convertirEnDTO(dossierMedical)))
                .orElse(ResponseEntity.notFound().build());
    }

    // Mettre à jour un dossier médical
    @PutMapping("/mettre-a-jour/{dossierId}")
    public ResponseEntity<DossierMedicalDTO> mettreAJourDossierMedical(
            @PathVariable Long dossierId,
            @RequestBody DossierMedicalDTO dossierMedicalDTO) {
        try {
            DossierMedical dossierMedical = dossierMedicalService.mettreAJourDossierMedical(dossierId, dossierMedicalDTO.getHistoriqueMaladies(), dossierMedicalDTO.getNotesMedecin());
            return ResponseEntity.ok(convertirEnDTO(dossierMedical));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null); // Vous pouvez personnaliser la réponse d'erreur
        }
    }

    // Méthode utilitaire pour convertir une entité DossierMedical en DTO
    private DossierMedicalDTO convertirEnDTO(DossierMedical dossierMedical) {
        DossierMedicalDTO dto = new DossierMedicalDTO();
        dto.setId(dossierMedical.getId());
        if (dossierMedical.getPatient() != null) {
            dto.setPatientId(dossierMedical.getPatient().getId());
        }
        dto.setHistoriqueMaladies(dossierMedical.getHistoriqueMaladies());
        dto.setNotesMedecin(dossierMedical.getNotesMedecin());
        return dto;
    }
}
