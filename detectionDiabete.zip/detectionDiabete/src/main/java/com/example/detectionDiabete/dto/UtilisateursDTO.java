package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UtilisateursDTO {
    private Long id; // Identifiant unique de l'utilisateur
    private String nom; // Nom de l'utilisateur
    private String prenom; // Prénom de l'utilisateur
    private String email; // Email de l'utilisateur
    private String motDePasse; // Mot de passe de l'utilisateur
    private String telephone;

    private String dateDeNaissance; // Date de naissance de l'utilisateur
    private String role; // Rôle de l'utilisateur (ex: Médecin, Patient)
}
