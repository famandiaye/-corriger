package com.example.detectionDiabete.services;

import com.example.detectionDiabete.dto.OrdonnanceDTO;
import com.example.detectionDiabete.entities.Medecin;
import com.example.detectionDiabete.entities.Notification;
import com.example.detectionDiabete.entities.RendezVous;
import com.example.detectionDiabete.entities.ResultatPatient;
import com.example.detectionDiabete.Repository.MedecinRepository; // Importez le repository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class MedecinService {

    @Autowired
    private UtilisateurService utilisateurService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private OrdonnanceService ordonnanceService;

    @Autowired
    private RendezVousService rendezVousService;

    @Autowired
    private ResultatPatientService resultatPatientService;

    @Autowired
    private MedecinRepository medecinRepository; // Injectez le repository

    // Récupérer tous les médecins
    public List<Medecin> findAll() {
        return medecinRepository.findAll(); // Utilisez le repository pour récupérer tous les médecins
    }

    // Modifier les informations d'un médecin
    public Medecin modifierMedecin(Long id, Medecin medecin) throws ParseException {
        return (Medecin) utilisateurService.modifierUtilisateur(id, medecin);
    }

    // Supprimer un médecin
    public void supprimerMedecin(Long id) {
        utilisateurService.supprimerUtilisateur(id);
    }

    // Récupérer un médecin par ID
    public Medecin getMedecinById(Long id) {
        return (Medecin) utilisateurService.trouverUtilisateurParId(id)
                .orElseThrow(() -> new RuntimeException("Médecin non trouvé avec ID: " + id));
    }

    // Récupérer toutes les notifications pour un médecin
    public List<Notification> recupererNotificationsPourMedecin(Long idMedecin) {
        return notificationService.recupererNotificationsPourMedecin(idMedecin);
    }

    // Prescrire un médicament
    public OrdonnanceDTO prescrireMedicament(OrdonnanceDTO ordonnanceDTO) {
        OrdonnanceDTO ordonnance = ordonnanceService.prescrireMedicament(ordonnanceDTO);

        Notification notification = new Notification();
        notification.setIdMedecin(ordonnanceDTO.getIdMedecin());
        notification.setIdPatient(ordonnanceDTO.getIdPatient());
        notification.setMessage("Médicament prescrit : " + ordonnanceDTO.getNom());
        notificationService.creerNotification(notification);

        return ordonnance;
    }

    // Proposer un rendez-vous
    public RendezVous proposerRendezVous(Long idMedecin, Long idPatient, LocalDateTime dateRendezVous) {
        return rendezVousService.proposerRendezVous(idMedecin, idPatient, dateRendezVous);
    }

    // Recevoir les résultats des patients
    public List<ResultatPatient> recevoirResultatsPatient(Long idMedecin) {
        return resultatPatientService.recupererResultatsPourMedecin(idMedecin);
    }

    // Discuter avec un patient
    public void discuterAvecPatient(Long idMedecin, Long idPatient, String message) {
        Notification notification = new Notification();
        notification.setIdMedecin(idMedecin);
        notification.setIdPatient(idPatient);
        notification.setMessage("Message de la part du médecin : " + message);
        notificationService.creerNotification(notification);
    }
}
