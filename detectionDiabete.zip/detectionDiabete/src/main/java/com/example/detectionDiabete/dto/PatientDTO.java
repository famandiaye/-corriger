package com.example.detectionDiabete.dto;

public class PatientDTO {
}
