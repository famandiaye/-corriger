package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.ResultatPatient;
import com.example.detectionDiabete.Repository.ResultatPatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ResultatPatientService {

    @Autowired
    private ResultatPatientRepository resultatPatientRepository;

    // Créer un résultat pour un patient
    public ResultatPatient creerResultat(Long idPatient, Long idMedecin, String contenu) {
        ResultatPatient resultatPatient = new ResultatPatient();
        resultatPatient.setIdPatient(idPatient);
        resultatPatient.setIdMedecin(idMedecin);
        resultatPatient.setResultat(contenu);
        resultatPatient.setDateReception(LocalDateTime.now());
        resultatPatient.setDateGeneration(LocalDateTime.now());

        return resultatPatientRepository.save(resultatPatient);
    }

    // Récupérer tous les résultats d'un patient
    public List<ResultatPatient> recupererResultats(Long idPatient) {
        List<ResultatPatient> resultats = resultatPatientRepository.findByIdPatient(idPatient);
        if (resultats.isEmpty()) {
            throw new RuntimeException("Aucun résultat trouvé pour le patient avec ID: " + idPatient);
        }
        return resultats;
    }

    // Récupérer un résultat spécifique par ID
    public Optional<ResultatPatient> findById(Long id) {
        return resultatPatientRepository.findById(id);
    }

    // Récupérer les résultats d'un médecin
    public List<ResultatPatient> recupererResultatsPourMedecin(Long idMedecin) {
        List<ResultatPatient> resultats = resultatPatientRepository.findByIdMedecin(idMedecin);
        if (resultats.isEmpty()) {
            throw new RuntimeException("Aucun résultat trouvé pour le médecin avec ID: " + idMedecin);
        }
        return resultats;
    }

    // Simuler la génération d'un résultat par l'IA
    public ResultatPatient genererResultatParIA(Long idPatient, Long idMedecin) {
        String resultatGenere = "Résultat généré par l'IA pour le patient " + idPatient;

        ResultatPatient resultatPatient = new ResultatPatient();
        resultatPatient.setIdPatient(idPatient);
        resultatPatient.setIdMedecin(idMedecin);
        resultatPatient.setResultat(resultatGenere);
        resultatPatient.setDateReception(LocalDateTime.now());
        resultatPatient.setDateGeneration(LocalDateTime.now());

        return resultatPatientRepository.save(resultatPatient);
    }

    // Supprimer un résultat par ID
    public void supprimerResultat(Long id) {
        resultatPatientRepository.deleteById(id);
    }
}
