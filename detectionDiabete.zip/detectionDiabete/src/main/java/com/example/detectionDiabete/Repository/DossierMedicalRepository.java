package com.example.detectionDiabete.Repository;

import com.example.detectionDiabete.entities.DossierMedical;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DossierMedicalRepository extends JpaRepository<DossierMedical, Long> {

  // Méthode pour trouver un dossier médical par l'ID du patient
  Optional<DossierMedical> findByPatient_Id(Long patientId);
}
